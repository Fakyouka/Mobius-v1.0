namespace Mobius.Models
{
    public enum AppSourceType
    {
        Manual = 0,
        Steam = 1
    }
}
