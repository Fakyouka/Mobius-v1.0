public class GameModel
{
    public string Name { get; set; }
    public string IconPath { get; set; }
    public string Source { get; set; } // Steam � AppID: 730
}
