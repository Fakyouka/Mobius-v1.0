﻿using System.Windows.Controls;

namespace Mobius.Views.Pages
{
    public partial class LibraryPage : UserControl
    {
        public LibraryPage()
        {
            InitializeComponent();
        }
    }
}
