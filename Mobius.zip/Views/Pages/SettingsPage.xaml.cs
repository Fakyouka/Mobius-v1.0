﻿using System.Windows.Controls;

namespace Mobius.Views.Pages
{
    public partial class SettingsPage : UserControl
    {
        public SettingsPage()
        {
            InitializeComponent();
        }
    }
}
